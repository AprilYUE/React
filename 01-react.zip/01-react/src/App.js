import React from 'react';
import logo from './favicon.ico';
import './App.css'
import LifeCycle from './LifeCycle';
import {Button} from 'antd'

//父子组件传值
function Welcome(props){
    return(
        <div>
            {props.name}
        </div>
    )
}

/* 
//使用函数的方式定义组件
function App(){
    return (
        <div>
            <img src={logo} style= {{width:200,height:200}} className="img"/>
        </div>
    )
}
 */

//使用ES6 class的方式定义组件
class App extends React.Component{
    //状态写在构造函数中
    constructor(props){
        super(props);

        //初始化状态
        this.state={
            date:new Date(),
            count:0
        }
    }

    componentDidMount(){ //类似vue的created
        this.timer = setInterval(()=>{
            //更新状态,不要直接更新状态,应该使用setState({}) || setState((preState,props)=>({}))
            this.setState({
                date:new Date()
            })
        },1000)

        //setState异步的说明，第二个参数回调函数可以实时查看状态
        this.setState({
            count:this.state.count+1 //依赖上一个状态，这种写法不可取，应传一个函数
        },()=>{console.log('里面的先触发：',this.state.count)})
        console.log('外面的先触发：',this.state.count)
        //依赖上一个状体时，传函数
        this.setState((prevState,props)=>({
            count:prevState.count+1
        }))
    }

    componentWillUnmount(){
        clearInterval(this.timer);
    }
    
    formatName(user){
        return user.firstName+user.lastName
    }
    render(){
        const name = 'Juicy';
        //jsx本身也是表达式
        const message = <h2>Hello Life</h2>
        return (
            <div>
                {/* antd的试用 */}
                <Button type="danger" shape="round">antd按钮</Button>
                {/* 表达式 */}
                <h1>hello {name} world</h1>
                <p>{this.formatName({firstName:'April',lastName:'Juicy'})}</p>
                {/* 属性 */}
                <img src={logo} style= {{width:100,height:100}} className="img"/>
                {/* jsx也是表达式 */}
                {message}
                {/* 组件属性传值 */}
                <Welcome name="好きだけど、さよなら"/>
                {/* 使用状态 */}
                {this.state.date.toLocaleTimeString()}
                {/* 生命周期 */}
                <LifeCycle/>
            </div>
        )
    }
}

export default App;
import React, { Component } from "react";

//Dialog
function Dialog(props) {
  return (
    <div style={{ border: `3px solid ${props.color || "balck"}` }}>
      {props.children}
      {/* 还可以把组件当一个属性传递 */}
      <div className="footer">{props.footer}</div>{" "}
    </div>
  );
}
function WelcomeDialog() {
  const confirmButton = (
    <button onClick={() => alert("react确实好")}>确定</button>
  );
  return (
    <Dialog color="red" footer={confirmButton}>
      <h1>欢迎</h1>
      <p>欢迎使用react!</p>
    </Dialog>
  );
}

export default class Composition extends Component {
  render() {
    return (
      <div>
        <WelcomeDialog />
      </div>
    );
  }
}

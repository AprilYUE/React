import React, { Component } from "react";

//1. 创建上下文
const Context = React.createContext();
const store = {
  name: "Juicy",
  sayHi() {
    console.log(this.name);
  }
};

const withProvider = Comp => props => (
  <Context.Provider value={store}>
    <Comp {...props} />
  </Context.Provider>
);
const withConsumer = Comp => props => (
  <Context.Consumer>
    {value => <Comp {...props} value={value} />}
  </Context.Consumer>
);


@withConsumer
class Inner extends Component {
  render() {
    return <div onClick={()=>this.props.value.sayHi()}>{this.props.value.name}</div>;
  }
}
@withProvider
class ContextSample extends Component {
  render() {
    return (
      //   <Context.Provider value={store}>
      //     {" "}
      //     {/* 这里必须叫value，把要传的值传进去 */}
      //     <div>
      //       <Context.Consumer>
      //         {/* 跨层级获取 */}
      //         {/* 必须内嵌一个函数,形参是传进来的值 */}
      //         {value => <div onClick={() => value.sayHi()}>{value.name}</div>}
      //       </Context.Consumer>
      //     </div>
      //   </Context.Provider>
      <div><Inner /></div>
    );
  }
}

export default ContextSample

import React, { Component } from 'react'

function MyFormCreate(comp){
    constructor(props){
        super(props);
        this.options={}; //字段选项设置
        this.state= {}; //各字段值
    }

    getFieldDec=(field,options,InputComp)=>{
        this.options[field]=option;
        return(
            
        )
    }
}

export default class MyForm extends Component {
  render() {
    return (
      <div>
          {
              /* getFieldDec('username',{
                  rules:[{required:true,message:'请填写用户名'}]
              })(<input type='text'/>) */
              getFieldDec('username',{
                rules:[{required:true,message:'请填写用户名'}]
            },<input type='text'/>)
          }
        {
            getFieldDec('password',{
                rules:[{required:true,message:'请填写密码'}]
            },<input type='password'/>)
        }
        
        <button>登录</button>
      </div>
    )
  }
}

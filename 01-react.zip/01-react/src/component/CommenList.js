import React, { Component, PureComponent } from "react";

//负责展示数据
/* function Comment({ data }) {
  //可以看到没一秒就被渲染一次，尽管没变化，即使不做DOM也要做diff算法对比数据变了没有
  //可以在生命周期shouldComponentUpdate进行优化，用生命周期的话就要使用class定义组件了
  console.log("render");
  return (
    <div>
      <p>{data.body}</p>
      <p>----{data.author}</p>
    </div>
  );
} */

const Comment = React.memo(({body,author})=>{
    return (
        <div>
          <p>{body}</p>
          <p>----{author}</p>
        </div>
      );
})

// class Comment extends PureComponent {
//   constructor(props) {
//       super(props)
//   }
//   /* shouldComponentUpdate(nextProps) {
//     //这个生命周期有两个参数nextProps,nextState
//     if (
//       nextProps.data.body === this.props.data.body &&
//       nextProps.data.author === this.props.data.author
//     ) {
//       return false;
//     }
//     return true;
//     //有没有方法代替这种逻辑？
//     //PureComponent 是定制了shouldComponentUpdate后的Component(浅比较)
//     //缺点是必须用class形式

//     //这里使用PureComponent后并没有阻止渲染？
//     //因为PureCompent进行比较的时候，先直接对对象进行比较，这样比较的仅仅是引用地址，当我们获取数据的时候
//     //数组是全新的，所以不起作用。然后它才对对象的长度和内容比较

//     //这个例子中怎么解决？
//     //使用PureComponent的原则：1. 确保数据类型是值类型，比如可以转化成字符串
//     //     2. 如果是引用类型，确保地址不变，同时不应当有深层次的数据变化
//   } */
//   render() {
//     console.log("render");
//     return (
//       <div>
//         <p>{this.props.body}</p>
//         <p>----{this.props.author}</p>
//       </div>
//     );
//   }
// }

//负责处理数据
export default class CommenList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      comments: []
    };
  }
  componentDidMount() {
    const timer = setInterval(() => {
      this.setState({
        comments: [
          { body: "react is good", author: "facebook" },
          { body: "vue is good", author: "youyuxi" }
        ]
      });
    }, 1000);
  }
  render() {
    return (
      <div>
        {this.state.comments.map((c, i) => (
          <Comment key={i}  /* body={c.body} author ={c.author} */ {...c} />
        ))}
      </div>
    );
  }
}

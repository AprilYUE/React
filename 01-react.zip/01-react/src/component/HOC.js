import React, { Component } from "react";
//高阶组件
const withName = Comp => {
    //甚至可以重写组件的生命周期
    class NewComp extends Component {
      componentDidMount() {
        console.log("do something");
      }
      render() {
        return <Comp {...this.props} name="高阶组件的使用" />;
      }
    }
    //假设通过特殊手段获取了name
    // return (props)=><Comp {...props} name="高阶组件的使用"></Comp>
    return NewComp;
  };
  const withLog = Comp => {
    console.log(Comp.name + "渲染了");
    return props => <Comp {...props} />;
  };


// function Show(props) {
//   return (
//     <div>
//       {/* 假设props.name在组件创建的时候得不到 */}
//       {props.stage}-{props.name}
//     </div>
//   );
// }

//从下往上依次执行
@withLog
@withName
class Show extends Component {
  render() {
    return (
      <div>
        {/* 假设props.name在组件创建的时候得不到 */}
        {this.props.stage}-{this.props.name}
      </div>
    );
  }
}
// export default withLog(withName(Show))
export default Show;

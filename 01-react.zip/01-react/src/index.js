import ReactDOM from 'react-dom';
import React from 'react';
import App from './App.js';
import CartSample from './CartSample.js';
import CommentList from './component/CommenList';
import Composition from './component/Composition';
import HOC from './component/HOC';
import ContextSample from './component/Context';
ReactDOM.render(
    // <App />
    // <CartSample title="React购物车"/>
    // <CommentList/>
    // <Composition></Composition>
    // <HOC stage="React"></HOC>
    <ContextSample></ContextSample>
    ,document.querySelector('#root')
)

import React, { Component } from "react";

export default class LifeCycle extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    console.log("1.构造函数", props);
  }
  componentWillMount() {
    //组件将要挂载
    console.log("2.组件将要挂载");
  }
  rend() {
    console.log("组件渲染");
  }
  componentDidMount() {
    //组件已经挂载，可进行状态更新
    console.log("3.组件已经挂载");
  }
  componentWillReceiveProps() {
    //父组件传递的属性有变化，做相应响应
    console.log("4.组件属性更新了");
  }
  shouldComponentUpdate() {
    //组件是否需要更新，返回布尔值，这是优化点
    console.log("5.组件是否应该更新");
    return true;
  }
  componentWillUpdate() {
    console.log("6.组件将要更新");
  }
  rend() {
    console.log("组件渲染");
  }
  componentDidUpdate() {
    console.log("7.组件已经更新");
  }
  render() {
    return <div />;
  }
}

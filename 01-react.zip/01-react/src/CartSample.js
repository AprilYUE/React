import React, { Component } from "react";

function Cart(props) {
  return (
    <div>
      <table>
        <tbody>
          {props.data.map(d => (
            <tr key={d.text}>
              <td>{d.text}</td>
              <td>
                <button onClick={() => props.delCount(d)}>-</button>
                {d.count}
                <button onClick={() => props.addCount(d)}>+</button>
              </td>
              <td>￥{d.price * d.count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default class CartSample extends Component {
  constructor(props) {
    super(props);
    this.state = {
      goods: [
        { id: 1, text: "Web全栈架构师", price: 666 },
        { id: 2, text: "Java", price: 666 }
      ],
      //   给输入框声明初始值
      text: "",
      cart: []
    };
    //事件回调写法一：把this绑死
    // this.addGood=this.addGood.bind(this);
  }
  //事件回调写法二：写成箭头函数
  addGood = () => {
    this.setState(preState => ({
      goods: [...preState.goods, { id: 3, text: preState.text, price: 666 }]
    }));
  };

  textChange = e => {
    this.setState({
      text: e.target.value
    });
  };

  addToCart(good) {
    const newCart = [...this.state.cart]; //因为它比较的是引用值，所以如果用push是不会渲染更新的
    const idx = newCart.findIndex(c => c.text === good.text);
    const item = newCart[idx];
    if (item) {
      //覆盖item展开的count，赋予count新值
      newCart.splice(idx, 1, { ...item, count: item.count + 1 });
    } else {
      newCart.push({ ...good, count: 1 });
    }

    this.setState({
      cart: newCart
    });
  }
  addCount = item => {
    const newCart = [...this.state.cart];
    const idx = newCart.findIndex(c => c.text === item.text);
    newCart.splice(idx, 1, { ...item, count: item.count + 1 });
    this.setState({
      cart: newCart
    });
  };
  delCount = item => {
    const newCart = [...this.state.cart];
    const idx = newCart.findIndex(c => c.text === item.text);
    if (item.count <= 1) {
      newCart.splice(idx, 1);
    } else {
      newCart.splice(idx, 1, { ...item, count: item.count - 1 });
    }
    this.setState({
      cart: newCart
    });
  };
  render() {
    const title = this.props.title ? <h1>{this.props.title}</h1> : null;
    //将JS数组转化为JSX数组
    const goods = this.state.goods.map(good => (
      // 和vue一样，也需要一个key
      <li key={good.id}>
        {good.text} <button onClick={() => this.addToCart(good)}>加购</button>
      </li>
    ));
    return (
      <div>
        {/* 条件语句 */}
        {/* 如果存在就执行，或者写在变量里 */}
        {/* {this.props.title && <h1>{this.title}</h1>} */}
        {title}
        {/* 添加商品 */}
        <div>
          <input type="text" onChange={e => this.textChange(e)} />
          <button onClick={this.addGood}>加到购物车</button>
          {/* 事件回调写法三： */}
          {/* <button onClick={()=>this.addGood()}>加到购物车</button> */}
        </div>

        {/* 列表渲染 */}
        <ul>{goods}</ul>

        {/* 购物车 */}
        <Cart
          data={this.state.cart}
          addCount={this.addCount}
          delCount={this.delCount}
        />
      </div>
    );
  }
}

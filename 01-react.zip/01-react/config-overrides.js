const {injectBabelPlugin} = require('react-app-rewired') //nodejs的导入方法，注入babel插件
module.exports = function override(config,env){ //参数一是要修改的config对象
    config=injectBabelPlugin([
        //第一个是要用的指令，是安装的babel-plugin-import，第二个是导的库,从哪里导，，连css一块导出
        'import',{libraryName:'antd',libraryDirectory:'es',style:'css'} //可以去antd的目录去看一下
    ],config); //把webpack默认的配置作为第二个参数传进去，参数一是自己要加载的模块
    config = injectBabelPlugin( //添加装饰器的能力
		['@babel/plugin-proposal-decorators',{"legacy":true}],
		config,
	)
    return config;
}